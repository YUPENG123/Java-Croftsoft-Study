     package com.croftsoft.core.gui.list;

     import java.awt.*;
     import java.awt.event.*;

     /*********************************************************************
     * <P>
     * @author
     *   <A HREF="http://www.alumni.caltech.edu/~croft">David W. Croft</A>
     * @version
     *   1998-04-12
     *********************************************************************/

     public interface  DoubleListDialogListener
     //////////////////////////////////////////////////////////////////////
     //////////////////////////////////////////////////////////////////////
     {

     public void  doubleListDialogAccept (
       String [ ]  items_left, String [ ]  items_right );

     //////////////////////////////////////////////////////////////////////
     //////////////////////////////////////////////////////////////////////
     }
