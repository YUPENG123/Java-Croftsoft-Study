The CroftSoft Code Library
Copyright 2003 CroftSoft Inc.

You may use the source code in the CroftSoft Code Library under the terms
of one of the following Open Source licenses:

* Academic Free License (AFL) v2.0
* GNU General Public License (GPL) v2
* GNU Lesser General Public License (LGPL) v2.1
* Open Software License (OSL) v2.0

I recommend the AFL as it appears to be the least restrictive.  The text
for each of these licenses is included in the lic/ subdirectory.  More
information about Open Source licensing is available at
http://www.opensource.org/.

The graphics and audio files included with the CroftSoft Code Library are
all in the Public Domain and may be used and modified without restriction.

The main Ant build file is build.xml.  The default project build
target will compile and launch a demo of animated games and
simulations.  If you are unfamiliar with the Open Source build tool
Ant, please see http://ant.apache.org/.

The CroftSoft Code Library was created by David Wallace Croft.  If you
have any queries or comments, his contact information is available at
http://www.croftsoft.com/people/david/.