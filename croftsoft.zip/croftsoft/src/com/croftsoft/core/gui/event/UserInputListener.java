     package com.croftsoft.core.gui.event;

     import java.awt.event.*;
     import javax.swing.event.*;

     /*********************************************************************
     * Extends KeyListener and MouseInputListener.
     *
     * @version
     *   2003-03-29
     * @since
     *   2003-03-29
     * @author
     *   <a href="http://www.croftsoft.com/">David Wallace Croft</a>
     *********************************************************************/

     public interface  UserInputListener
       extends KeyListener, MouseInputListener
     //////////////////////////////////////////////////////////////////////
     //////////////////////////////////////////////////////////////////////
     {

     //////////////////////////////////////////////////////////////////////
     //////////////////////////////////////////////////////////////////////
     }
